<?php 

	session_start();
	
	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>	
			<title>Deleting A Book</title>
		</head>";
		
	echo "<body><div class='upper'><h1 class='libraryhead'>Deleting A Book</h1></div>";
	
	echo "<div class='search'>
			<form method='post'>
				<fieldset>
				<legend>Please enter the book ISBN</legend>
				<label for='31'>ISBN</label><input id='31' type='text' name='bookid' placeholder='Book ISBN' required><br>				
				</fieldset>
				<input type='submit' value='Delete book' name='submit'>
			</form>
		</div>";
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$database = "library";
	$con = mysqli_connect ( $servername, $username, $password, $database );
	if (! $con) {
		die ( "Connection failed: " . mysqli_connect_error () );
	}
	if (isset ( $_POST ['submit'] )) {
		$bookid = $_POST ['bookid'];
		$validatesql = "select * from book where book_id='$bookid'";
		$result = mysqli_query ( $con, $validatesql );
		if (mysqli_num_rows ( $result ) == 0) {
			echo "<p>Book not exists! Please re-enter the ISBN10.</p>";
		} else {
			$sql = "delete from book where book_id='$bookid';";
			mysqli_query ( $con, $sql );
			$validatesql = "select * from book where book_id='$bookid'";
			$result = mysqli_query ( $con, $validatesql );
			if (mysqli_num_rows ( $result ) == 0) {
				echo "<p>This book with ISBN10 ".$bookid." has been deleted successfully.</p>";
			}
		}
	}

	$cardNumber = $_SESSION['cardNumber'];
	$userTypeCheck = "SELECT Usertype FROM borrower b WHERE b.Card_no='$cardNumber'";
	$userTypeCheckResult = mysqli_query($con, $userTypeCheck);
	if(mysqli_num_rows($userTypeCheckResult)>0){
		$row = mysqli_fetch_assoc($userTypeCheckResult);
		if($row["Usertype"] == 'user'){
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='userInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}else{
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}			
	}

?>