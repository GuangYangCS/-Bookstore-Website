<?php
	
	$uri = explode("/",$_SERVER['REQUEST_URI']);
	$size = sizeof($uri);
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "babynames";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
		
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	
	if($size == 2){
		echo "<table border='1' style='border-collapse: collapse; border: 2px solid black;'><tr><th>Book_ID</th><th>Title</th><th>Year</th><th>Price</th><th>Category</th></tr>";
		$sql = "SELECT Book_id, Title, Year, Price, Category
				FROM book";
		$result = mysqli_query($conn, $sql);
		if (mysqli_num_rows($result)>0) {
			while($row = mysqli_fetch_assoc($result)){
				echo "<tr><td>".$row["Book_id"]."</td><td>".$row["Title"]."</td><td>".$row["Year"]."</td><td>".$row["Price"]."</td><td>".$row["Category"]."</td></tr>";
			}
		}else{
			echo "0 results";
		}
		echo "</table>";
	}
	
	if($size == 3){
		$id = $uri[2];
		echo "<table border='1' style='border-collapse: collapse; border: 2px solid black;'><tr><th>Book_ID</th><th>Title</th><th>Year</th><th>Price</th><th>Category</th><th>Authors</th></tr>";
		
		$sql = "SELECT Book_id, Title, Year, Price, Category
				FROM book
				WHERE Book_id=$id";
		$result = mysqli_query($conn, $sql);
		if (mysqli_num_rows($result)>0) {
			$row = mysqli_fetch_assoc($result);
			echo "<tr><td>".$row["Book_id"]."</td><td>".$row["Title"]."</td><td>".$row["Year"]."</td><td>".$row["Price"]."</td><td>".$row["Category"]."</td>";
			$sql1 = "SELECT a.author_name
				     FROM authors a, book_authors b
					 WHERE b.Book_id=$id AND a.author_id = b.Author_id";
			$result1 = mysqli_query($conn, $sql1);
			$authors ="";
			if (mysqli_num_rows($result1)>0) {
				while($row = mysqli_fetch_assoc($result1)){
					$authors = $authors.$row["author_name"].", ";
				}
			}
			$authors = substr($authors,0,strlen($authors)-2);
			echo "<td>".$authors."</td></tr>";
		}else{
			echo "0 results";
		}
		echo "</table>";
	}
	
	mysqli_close($conn);
	
?>