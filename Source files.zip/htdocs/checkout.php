<?php

	session_start();

	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>
			<title>Registering</title>
		</head>";
	
	$bookid = $_POST['bookid'];
	$branchid = $_POST['branchid'];
	$cardnum = $_SESSION['cardNumber'];
	
	echo "<body><div class='upper'><h1 class='libraryhead'>Checking Out</h1></div>";
	echo "<p>The book id is ".$bookid.", the branch id is ".$branchid." and the card number is ".$cardnum.".</p>";
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	
	date_default_timezone_set('America/Chicago');

	$trimcardnum=trim($cardnum);
	
	$sql = "SELECT * FROM borrower WHERE Card_no=$trimcardnum";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result)>0){
		$sql1 = "SELECT COUNT(*) AS Borrowed
				 FROM book_loans bl
				 WHERE bl.Date_in='0000-00-00' AND bl.Card_no=$trimcardnum";
		$result1 = mysqli_query($conn, $sql1);
		$number = 0;
		if(mysqli_num_rows($result1)>0){
			$row = mysqli_fetch_assoc($result1);
			$number = $row["Borrowed"];
		}
		if($number>=3){
			echo "<p>You are keeping 3 books and can't borrow more books now.</p>";
		}else{
			$outdate = date("Y/m/d");
			$duedate = date("Y/m/d", strtotime($outdate."+13 days"));
			$sql2 = "INSERT INTO book_loans(Book_id, Branch_id, Card_no, Date_out, Due_date, Date_in)
					 VALUES('$bookid', $branchid, $trimcardnum,'$outdate', '$duedate', '0000-00-00')";
			$result2 = mysqli_query($conn, $sql2);
			echo "<p>Borrow successfully.</p>";
		}
	}else{
		echo "<p>The user does not exist and can not borrow book.</p>";
		echo "<div class='search'><form style='display:inline' action='checkout.php' method='post'>
				<fieldset>
				<input type='hidden' name='bookid' value='$bookid'>
				<input type='hidden' name='branchid' value='$branchid'>
				</fieldset>
				<input type='submit' value='Re-enter another card number'>
			  </form></div>";
	}
	
	$cardNumber = $_SESSION['cardNumber'];
	$userTypeCheck = "SELECT Usertype FROM borrower b WHERE b.Card_no='$cardNumber'";
	$userTypeCheckResult = mysqli_query($conn, $userTypeCheck);
	if(mysqli_num_rows($userTypeCheckResult)>0){
		$row = mysqli_fetch_assoc($userTypeCheckResult);
		if($row["Usertype"] == 'user'){
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='userInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}else{
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}			
	}
	
	mysqli_close($conn);
		
?>