<?php 

	session_start();
	
	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>	
			<title>Updating A Book</title>
		</head>";
		
	echo "<body><div class='upper'><h1 class='libraryhead'>Updating A Book</h1></div>";

	$bookid = trim ( $_POST ['bookid'] );
	$title = trim ( $_POST ['title'] );
	$author = trim ( $_POST ['author'] );
	$branch = trim ( $_POST ['branch'] );
	$copies = trim ( $_POST ['copies'] );
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$database = "library";
	$con = mysqli_connect ( $servername, $username, $password, $database );
	if (! $con) {
		die ( "Connection failed: " . mysqli_connect_error () );
	}

	echo "<div class='search'>
			<form method='post'>
				<fieldset>
				<legend>Updating book</legend>
				<label for='51'>ISBN</label><input id='51' type='text' name='bookid' value='$bookid' placeholder='Book ISBN' required><br>
				<label for='52'>Title</label><input id='52' type='text' name='title' value='$title' placeholder='Book Title' required><br>
				<label for='53'>Author</label><input id='53' type='text' name='author' value='$author' placeholder='Book Author' required><br>
				<label for='54'>Branch</label><input id='54' type='number' name='branch' value='$branch' placeholder='Book Branch' required><br>
				<label for='55'>Number of Copies</label><input id='55' type='number' value='$copies' name='copies' placeholder='Book Copies' required><br>
				</fieldset>
				<input type='submit' value='Update book' name='submit'>
			</form>
		</div>";

	if (isset ( $_POST ['submit'] )) {
		$newbookid =$_POST['bookid'] ;
		$newtitle = $_POST ['title'] ;
		$newauthor =$_POST ['author'] ;
		$newbranch =$_POST ['branch'] ;
		$newcopies =$_POST ['copies'] ;
		
		$sql = "update book set book_id=$newbookid,title='$title' where book_id='$newbookid';";
		$sql .= "update book_authors set book_id=$newbookid,author_name='$newauthor'
		where book_id='$newbookid';";
		$sql .= "update book_copies set book_id=$newbookid,branch_id='$newbranch',no_of_copies='$newcopies'
		where book_id='$newbookid';";
		mysqli_multi_query ( $con, $sql );
		echo "<p>Update successful!</p>";
	}

	$cardNumber = $_SESSION['cardNumber'];
	$userTypeCheck = "SELECT Usertype FROM borrower b WHERE b.Card_no='$cardNumber'";
	$userTypeCheckResult = mysqli_query($con, $userTypeCheck);
	$row = mysqli_fetch_assoc($userTypeCheckResult);
	if($row["Usertype"] == 'user'){
		echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='userInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
	}else{
		echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
	}			

?>