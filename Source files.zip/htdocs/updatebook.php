<?php

	session_start();
	
	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>	
			<title>Updating A Book</title>
		</head>";
		
	echo "<body><div class='upper'><h1 class='libraryhead'>Updating A Book</h1></div>";
	
	echo "<div class='search'>
			<form method='post'>
				<fieldset>
				<legend>Please enter the book ISBN</legend>
				<label for='41'>ISBN</label><input id='41' type='text' name='bookid' placeholder='Book ISBN' required><br>				
				</fieldset>
				<input type='submit' value='Update book' name='submit'>
			</form>
		</div>";
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$database = "library";
	$con = mysqli_connect ( $servername, $username, $password, $database );
	if (! $con) {
		die ( "Connection failed: " . mysqli_connect_error () );
	}

	if (isset ( $_POST ['submit'] )) {
		$bookid = $_POST ['bookid'];
		$sql1 = "select book.book_id,book.title,author_name,branch_id,no_of_copies
					from book,book_authors,book_copies
					where book.book_id=book_authors.book_id and book_authors.book_id=book_copies.book_id
					and book.book_id='$bookid'";
		$result = mysqli_query ( $con, $sql1 );
		$row = mysqli_fetch_assoc ( $result );
		$resultbookid = $row ["book_id"];
		$title = $row ["title"];
		$author = $row ["author_name"];
		$branch = $row ["branch_id"];
		$copies = $row ["no_of_copies"];
		echo "<div><table border='1'>
					<tr>
						<th>book id</th>
						<th>title</th>
						<th>author</th>
						<th>branch_id</th>
						<th>copies</th>
						<th>update</th>
					</tr>";
		
		$updatebtn = "<form action='updatebookresult.php' method='post' style='display:inline'>
						<input id='bookid' name='bookid' value='$resultbookid' type='hidden'>
						<input id='title' name='title' value='$title' type='hidden'>
						<input id='author' name='author' value='$author' type='hidden'>
						<input id='branch' name='branch' value='$branch' type='hidden'>
						<input id='copies' name='copies' value='$copies' type='hidden'>
						<input type='submit' value='Update' name='submit2'>
					</form>";
		
		echo "<tr>		<td>" . $row ["book_id"] . "</td>" . "<td>" . $row ["title"] . "</td>" . "<td>" . $row ["author_name"] . "</td>" . "<td>" . $row ["branch_id"] . "</td>" . "<td>" . $row ["no_of_copies"] . "</td>" . "<td>" . $updatebtn . "</td>" . "</tr>";
	}
	echo "</table></div>";

	$cardNumber = $_SESSION['cardNumber'];
	$userTypeCheck = "SELECT Usertype FROM borrower b WHERE b.Card_no='$cardNumber'";
	$userTypeCheckResult = mysqli_query($con, $userTypeCheck);
	if(mysqli_num_rows($userTypeCheckResult)>0){
		$row = mysqli_fetch_assoc($userTypeCheckResult);
		if($row["Usertype"] == 'user'){
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='userInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}else{
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}			
	}

?>