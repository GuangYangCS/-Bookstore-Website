<?php

	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>
			<title>Refreshing</title>
		</head>";

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	echo "<body><div class='upper'><h1 class='libraryhead'>Refreshing fines</h1></div>";
	
	date_default_timezone_set('America/Chicago');
	$today = date("Y/m/d");
	$today1 = date_create($today);
	
	$sql = "SELECT Loan_id, Due_date, Date_in
			FROM book_loans
			WHERE (Date_in='0000-00-00' AND curdate()>Due_date) OR (Date_in>Due_date)";
	$result = mysqli_query($conn, $sql);
	
	if (mysqli_num_rows($result)>0) {
		while($row = mysqli_fetch_assoc($result)){
			//count the amount of fines
			$duedate = $row["Due_date"];
			$duedate1 = date_create($duedate);
			$indate = $row["Date_in"];
			$indate1 = date_create($indate);
			if($row["Date_in"]=='0000-00-00'){
				$days = date_diff($today1,$duedate1);
			}else{
				$days = date_diff($indate1,$duedate1);
			}
			$days1 = $days->format("%a");
			$amount = 0.25*$days1;
			
			$loanid = $row["Loan_id"];		
			//use loan ID to check whether the loan_ID is in the fines table
			$sql1 = "SELECT *
					 FROM fines
					 WHERE Loan_id=$loanid AND Paid=1";
			$result1 = mysqli_query($conn, $sql1);
			
			//check wether the loan ID is in the fines table
			if(mysqli_num_rows($result1)>0){		//if the loan ID is in the fines table, update
				$sql2 = "UPDATE fines
						 SET Fine_amt=$amount
						 WHERE Loan_id=$loanid";
				//echo "<br>Update successfully";
			}else{				//if the loan ID is not in the fines table, insert
				$sql2 = "INSERT fines(Loan_id, Fine_amt, Paid)
			             VALUES($loanid, $amount, 1)";
				//echo "<br>Insert successfully";
			}
			$result2 = mysqli_query($conn, $sql2);
		}
		echo "<p>Refresh successfully.</p>";
	}else{
		echo "<p>0 results.</p>";
	}
	echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		
	mysqli_close($conn);
?>