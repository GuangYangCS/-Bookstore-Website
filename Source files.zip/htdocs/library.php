<?php

	session_start();
		
	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>	
			<title>Seaeching Book Results</title>
		</head>";
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	
	$bookid = $_POST['bookid'];
	$title = $_POST['title'];
	$author = $_POST['author'];
	
	echo "<body><div class='upper'><h1 class='libraryhead'>Search Result</h1></div>";
	
	$trimbookid=trim($bookid);
	$trimauthor=trim($author);
	$trimtitle=trim($title);
	
	
	echo "<div><table border='1'><tr><th>Book_ID</th><th>Title</th><th>Author</th><th>Branch_ID</th><th>Number Of Copies</th><th>Number OF Availability</th><th>CheckOut</th></tr>";
	
	if(strlen($trimbookid)==10){
		$sql4 = "SELECT b.Book_id, Title, ba.Author_Name, bc.Branch_id, bc.No_of_copies
				 FROM book b, book_authors ba, book_copies bc 
				 WHERE b.Book_id=ba.Book_id
				   AND b.Book_id=bc.Book_id
				   AND b.Book_id='$trimbookid'";
	}else if(strlen($trimbookid)<10 && strlen($trimbookid)>0){
		$sql4 = "SELECT book.Book_id, Title, Author_Name, Branch_id, No_of_copies 
				 FROM book, book_authors, book_copies 
				 WHERE book.Book_id=book_authors.Book_id 
				   AND book.Book_id=book_copies.Book_id  
				   AND book.Book_id like '%$trimbookid%'";
	}else if(strlen($trimauthor)!=0 && strlen($trimtitle)!=0){
		$sql4 = "SELECT book.Book_id, Title, Author_Name, Branch_id, No_of_copies 
				 FROM book, book_authors, book_copies 
				 WHERE book.Book_id=book_authors.Book_id 
				   AND book.Book_id=book_copies.Book_id 
				   AND Author_Name like '%$trimauthor%' 
				   AND Title like '%$trimtitle%'";
	}else if(strlen($trimauthor)!=0){
		$sql4 = "SELECT book.Book_id, Title, Author_Name, Branch_id, No_of_copies 
				 FROM book, book_authors, book_copies 
				 WHERE book.Book_id=book_authors.Book_id 
				   AND book.Book_id=book_copies.Book_id 
				   AND Author_Name like '%$trimauthor%'";
	}else if(strlen($trimtitle)!=0){
		$sql4 = "SELECT book.Book_id, Title, Author_Name, Branch_id, No_of_copies 
				 FROM book, book_authors, book_copies 
				 WHERE book.Book_id=book_authors.Book_id 
				   AND book.Book_id=book_copies.Book_id 
				   AND Title like '%$trimtitle%'";
	}
	
	$result4 = mysqli_query($conn, $sql4);
	if (mysqli_num_rows($result4)>0) {
		while($row = mysqli_fetch_assoc($result4)) {
			$id1 = $row["Book_id"];
			$id2 = $row["Branch_id"];
			$sql5 = "SELECT COUNT(*) AS Borrowed
					 FROM book_loans bl
					 WHERE bl.Date_in='0000-00-00' AND bl.Book_id=$id1 AND bl.Branch_id=$id2
					 GROUP BY bl.Book_id, bl.Branch_id";
			$result5 = mysqli_query($conn, $sql5);
			$number = 0;
			if(mysqli_num_rows($result5)>0){
				$r1 = mysqli_fetch_assoc($result5);
				$number = $r1["Borrowed"];
			}
			$availability = $row["No_of_copies"]- $number;
			$chosedbookid = $row["Book_id"];
			$chosedbranchid = $row["Branch_id"];
			if($availability > 0){
				echo "<tr><td>".$row["Book_id"]."</td><td>".$row["Title"]."</td><td>".$row["Author_Name"]."</td><td>".$row["Branch_id"]."</td><td>".$row["No_of_copies"]."</td><td>".$availability."</td><td style='text-align: center'>"."<form style='display:inline;' action='checkout.php' method='post'><input type='hidden' name='bookid' value='$chosedbookid'><input type='hidden' name='branchid' value='$chosedbranchid'><input type='submit' value='Check Out'></form>"."</td></tr>";	
			}else{
				echo "<tr><td>".$row["Book_id"]."</td><td>".$row["Title"]."</td><td>".$row["Author_Name"]."</td><td>".$row["Branch_id"]."</td><td>".$row["No_of_copies"]."</td><td>".$availability."</td><td style='text-align: center'>"."<button style='display:inline;' onclick=printAlert()>Check Out</button>"."</td></tr><script>function printAlert(){alert ('This book in this branch is not available now.');}</script>";
			}
		}
	}else{
		echo "<p>0 results</p>";
	}
	echo "</table></div>";
	
	$cardNumber = $_SESSION['cardNumber'];
	$userTypeCheck = "SELECT Usertype FROM borrower b WHERE b.Card_no='$cardNumber'";
	$userTypeCheckResult = mysqli_query($conn, $userTypeCheck);
	if(mysqli_num_rows($userTypeCheckResult)>0){
		$row = mysqli_fetch_assoc($userTypeCheckResult);
		if($row["Usertype"] == 'user'){
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='userInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}else{
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}			
	}
	
	mysqli_close($conn);

?>