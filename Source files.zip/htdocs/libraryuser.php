<?php
	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>
			<title>Registering</title>
		</head>";
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	
	echo "<body><div class='upper'><h1 class='libraryhead'>Registering</h1></div>";
	
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$address = $_POST['address'];
	$password = $_POST['password'];
	$username = $_POST['username'];
	
	
	$trimfname=trim($fname);
	$trimlname=trim($lname);
	$trimaddress=trim($address);
	$trimusername=trim($username);
	$trimpassword=trim($password);
	
	if(strlen($trimfname)==0 || strlen($trimlname)==0 || strlen($trimaddress)==0 || strlen($trimusername)==0 || strlen($trimpassword)==0){
		echo "<p>You must enter the last name, first name, email address, username and password.</p>";
		
	}else{
		$duplicate_check = "SELECT * FROM borrower b WHERE (b.Fname='$trimfname' AND b.Lname='$trimlname') OR b.Address='$trimaddress' OR b.Username='$trimusername'";
		$check_result = mysqli_query($conn, $duplicate_check);
		if(mysqli_num_rows($check_result)>0){
			include ("Library_manage_system.html");
			echo "<p>The account you want to create already exists.</p>";
		}else{
			$sql = "INSERT INTO borrower(Card_no, Fname, Lname, Email_Address, Username, Password)
					VALUES(NULL, '$trimfname', '$trimlname', '$trimaddress', '$trimusername', '$trimpassword')";
			$result = mysqli_query($conn, $sql);
			$sql1 = "SELECT Card_no
					 FROM borrower
					 WHERE Fname='$trimfname' AND Lname='$trimlname' AND Address='$trimaddress'";
			$result1 = mysqli_query($conn, $sql1);
			if(mysqli_num_rows($result1)>0){
				$row = mysqli_fetch_assoc($result1);
				$cardnumber = $row["Card_no"];
			}
			echo "<p>A new account is created successfully, and the card number is ".$cardnumber.".</p>";
		}
	}

	mysqli_close($conn);
	
	echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='Library_manage_system.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
	
?>