<?php

	session_start();

	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>
			<title>Paying Fines</title>
		</head>";

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	
	$cardnum = $_POST['cardno'];
	if($cardnum > 0){
		$trimcardnum=trim($cardnum);
	}else{
		$trimcardnum=$_SESSION['cardNumber'];
	}
		
		
	echo"<style> th, td{width:11%}</style>";
	echo "<body><div class='upper'><h1 class='libraryhead'>Paying Fines</h1></div>";
	echo "<p>The entered card number is ".$trimcardnum.".</p>";
	
	//check whether the user has book not returned
	$sql1="SELECT bl.Loan_id
		   FROM book_loans bl, fines f
		   WHERE bl.Card_no=$trimcardnum
		     AND bl.Loan_id=f.Loan_id
		     AND f.Fine_amt>0
		     AND bl.Date_in='0000-00-00'";
	$result1 = mysqli_query($conn, $sql1);
	if (mysqli_num_rows($result1)>0){
		$sql3 = "SELECT Book_id, Branch_id, Date_out, Due_date, Date_in, bl.Loan_id, Card_no, Fine_amt, Paid
				 FROM book_loans bl, fines f
				 WHERE bl.Card_no=$trimcardnum
				   AND bl.Loan_id=f.Loan_id
				   AND f.Fine_amt>0
				   AND f.Paid =1";
		$result3 = mysqli_query($conn, $sql3);
		echo "<table border='1'><tr><th>Book_ID</th><th>Branch_ID</th><th>Date_out</th><th>Due_date</th><th>Date_in</th><th>Loan_ID</th><th>Card_NO.</th><th>Fine_Amount</th><th>Paid</th></tr>";
		$sum1 = 0;
		while($row = mysqli_fetch_assoc($result3)){
			$sum1+=$row["Fine_amt"];
			echo "<tr><td>".$row["Book_id"]."</td><td>".$row["Branch_id"]."</td><td>".$row["Date_out"]."</td><td>".$row["Due_date"]."</td><td>".$row["Date_in"]."</td><td>".$row["Loan_id"]."</td><td>".$row["Card_no"]."</td><td>".$row["Fine_amt"]."</td><td>".$row["Paid"]."</td></tr>";
		}
		echo "<tr><td>SUM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>".$sum1."</td></tr></table>";
		echo "<p>You have some books overdue and don't return it. Please return them first.</p>";
	}else{
		//check whether the user have fines
		$sql2 = "SELECT Book_id, Branch_id, Date_out, Due_date, Date_in, bl.Loan_id, Card_no, Fine_amt, Paid
				 FROM book_loans bl, fines f
				 WHERE bl.Card_no=$trimcardnum
				   AND bl.Loan_id=f.Loan_id
				   AND f.Fine_amt>0
				   AND f.Paid =1";
		$result2 = mysqli_query($conn, $sql2);
		if(mysqli_num_rows($result2)>0){
			//you need pay some fines
			
			echo "<table border='1'><tr><th>Book_ID</th><th>Branch_ID</th><th>Date_out</th><th>Due_date</th><th>Date_in</th><th>Loan_ID</th><th>Card_NO.</th><th>Fine_Amount</th><th>Paid</th></tr>";
			$sum = 0;
			while($row = mysqli_fetch_assoc($result2)){
				$sum+=$row["Fine_amt"];
				$cardnum=$row["Card_no"];
				echo "<tr><td>".$row["Book_id"]."</td><td>".$row["Branch_id"]."</td><td>".$row["Date_out"]."</td><td>".$row["Due_date"]."</td><td>".$row["Date_in"]."</td><td>".$row["Loan_id"]."</td><td>".$row["Card_no"]."</td><td>".$row["Fine_amt"]."</td><td>".$row["Paid"]."</td></tr>";
			}
			echo "<tr><td>SUM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>".$sum."</td></tr></table><br>";
			echo "<div class='search'><form action='pay.php' method='post'><input type='hidden' name='cardnum' value='$cardnum'><input type='submit' value='Pay'></form></div>";
		}else{
			//you have not fines
			$sql4 = "SELECT Book_id, Branch_id, Date_out, Due_date, Date_in, bl.Loan_id, Card_no, Fine_amt, Paid
					 FROM book_loans bl, fines f
					 WHERE bl.Card_no=$trimcardnum
					 AND bl.Loan_id=f.Loan_id
					 AND f.Fine_amt>0";
			$result4 = mysqli_query($conn, $sql4);
			echo "<table border='1'><tr><th>Book_ID</th><th>Branch_ID</th><th>Date_out</th><th>Due_date</th><th>Date_in</th><th>Loan_ID</th><th>Card_NO.</th><th>Fine_Amount</th><th>Paid</th></tr>";
			$sum2 = 0;
			while($row = mysqli_fetch_assoc($result4)){
				$sum2+=$row["Fine_amt"];
				echo "<tr><td>".$row["Book_id"]."</td><td>".$row["Branch_id"]."</td><td>".$row["Date_out"]."</td><td>".$row["Due_date"]."</td><td>".$row["Date_in"]."</td><td>".$row["Loan_id"]."</td><td>".$row["Card_no"]."</td><td>".$row["Fine_amt"]."</td><td>".$row["Paid"]."</td></tr>";
			}
			echo "<tr><td>SUM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>".$sum2."</td></tr></table>";
			
			echo "<p>You don't have fines.</p>";
		}
	}
	
	$cardNumber = $_SESSION['cardNumber'];
	$userTypeCheck = "SELECT Usertype FROM borrower b WHERE b.Card_no='$cardNumber'";
	$userTypeCheckResult = mysqli_query($conn, $userTypeCheck);
	if(mysqli_num_rows($userTypeCheckResult)>0){
		$row = mysqli_fetch_assoc($userTypeCheckResult);
		if($row["Usertype"] == 'user'){
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='userInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}else{
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}			
	}
	
	mysqli_close($conn);
	
?>