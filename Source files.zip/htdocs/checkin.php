<?php 

	session_start();

	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>
			<title>Checking In</title>
		</head>";
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	
	$loanid = $_POST['loanid'];
	$trimloanid=trim($loanid);
	
	echo "<body><div class='upper'><h1 class='libraryhead'>Checking In</h1></div>";
	
	echo "<p>The loan ID is ".$loanid.".</p>";
	
	$indate = date("Y/m/d");
	
	$sql = "UPDATE book_loans
			SET Date_in='$indate'
			WHERE Loan_id=$loanid";
	$result = mysqli_query($conn, $sql);
	
	echo "<p>Check in successfully.</p>";
	
	$cardNumber = $_SESSION['cardNumber'];
	$userTypeCheck = "SELECT Usertype FROM borrower b WHERE b.Card_no='$cardNumber'";
	$userTypeCheckResult = mysqli_query($conn, $userTypeCheck);
	if(mysqli_num_rows($userTypeCheckResult)>0){
		$row = mysqli_fetch_assoc($userTypeCheckResult);
		if($row["Usertype"] == 'user'){
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='userInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}else{
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}			
	}
		
	mysqli_close($conn);

?>