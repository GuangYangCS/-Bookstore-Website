<?php 
	session_unset();
	session_destroy();
	
	
	header("Location: http://localhost:1980/login.html");
	exit;
	
	
?>