<?php
    session_start();
	
	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>	
			<title>Adding A NEW Book</title>
		</head>";
		
	echo "<body><div class='upper'><h1 class='libraryhead'>Adding A NEW Book</h1></div>";

	echo "<div class='search'>
			<form method='post'>
				<fieldset>
				<legend>Adding book</legend>
				<label for='21'>ISBN</label><input id='21' type='text' name='bookid' placeholder='Book ISBN' required><br>
				<label for='22'>Title</label><input id='22' type='text' name='title' placeholder='Book Title' required><br>
				<label for='23'>Author</label><input id='23' type='text' name='author' placeholder='Book Author' required><br>
				<label for='24'>Branch</label><input id='24' type='number' name='branch' placeholder='Book Branch' required><br>
				<label for='25'>Number of Copies</label><input id='25' type='number' name='copies' placeholder='Book Copies' required><br>
				</fieldset>
				<input type='submit' value='Add book' name='submit'>
			</form>
		</div>";

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$database = "library";
	$con = mysqli_connect ( $servername, $username, $password, $database );
	if (! $con) {
		die ( "Connection failed: " . mysqli_connect_error () );
	}
	if (isset ( $_POST ['submit'] )) {
		if (! $_POST ['bookid']) {
			$error ['bookid'] = "<p>Please supply bookid.</p>\n";
		}
		if (! $_POST ['title']) {
			$error ['title'] = "<p>Please supply book title.</p>\n";
		}
		
		$bookid = $_POST ['bookid'];
		$title = $_POST ['title'];
		$author = $_POST ['author'];
		$branch = $_POST ['branch'];
		$copies = $_POST ['copies'];
		
		$validatesql = "select * from book where book_id='$bookid'";
		$result = mysqli_query ( $con, $validatesql );
		if (mysqli_num_rows ( $result ) > 0) {
			echo "Duplicate book exists.";
			
		} else {
			$sql = "insert into book values('$bookid','$title');";
			$sql .= "insert into book_authors values('$bookid','$author');";
			$sql .= "insert into book_copies values('$bookid','$branch','$copies');";
			mysqli_multi_query ( $con, $sql );
			echo "<p>Book added!</p>";
		}
	}

	echo "<div style='padding-left: 20px; padding-bottom: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
	
?>