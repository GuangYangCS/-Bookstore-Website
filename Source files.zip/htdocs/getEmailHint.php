<?php

	session_start();

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	
	$q = $_REQUEST["q"];
	$email = mysqli_real_escape_string($con,$q);
	
	if ($email !== "") {
		$duplicate_check = "SELECT * FROM borrower b WHERE b.Email_Address='$email'";
		$check_result = mysqli_query($conn, $duplicate_check);
		if(mysqli_num_rows($check_result)>0){
			echo "The email you enter already exists.";
		}else{
			echo "";
		}
	}else{
		echo "";
	}
	
	mysqli_close($conn);
	
?>