<?php

	session_start();
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}

	$nameOrEmail = $_POST['username'];
	$loginpassword = $_POST['password'];
	
	$trimnameOrEmail=trim($nameOrEmail);
	$trimloginpassword=trim($loginpassword);
	
	if(strlen($trimnameOrEmail)==0){
		echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>	
			<title>Library Management System</title>
		</head>";
		echo "<body><div class='upper'><h1 class='libraryhead'>Library Management System</h1></div>";
		echo "<p>You must enter your email address or username.</p>";
		header("Location: http://localhost:1980/login.html");
		
	}else if(strlen($trimloginpassword)==0){
		echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>	
			<title>Library Management System</title>
		</head>";
		
		echo "<body><div class='upper'><h1 class='libraryhead'>Library Management System</h1></div>";
		echo "<p>You must enter your password.</p>";
		header("Location: http://localhost:1980/login.html");
	}else{
		$name_check = "SELECT * FROM borrower b WHERE b.Username='$trimnameOrEmail' OR b.Email_Address='$trimnameOrEmail'";
		$name_check_result = mysqli_query($conn, $name_check);
		if(mysqli_num_rows($name_check_result)>0){
			$password_check = "SELECT Card_no, Usertype FROM borrower b WHERE (b.Username='$trimnameOrEmail' OR b.Email_Address='$trimnameOrEmail') AND b.Password='$trimloginpassword'";
			$password_check_result = mysqli_query($conn, $password_check);
			if(mysqli_num_rows($password_check_result)>0){
				$row = mysqli_fetch_assoc($password_check_result);
				$_SESSION['cardNumber'] = $row["Card_no"];
				if($row["Usertype"] == 'user'){
					include ("userInterface.html");
				}else{
					include ("adminInterface.html");
				}
				
			}else{
				echo"<head>
						<link href='project1.css' type='text/css' rel='stylesheet'/>	
						<title>Library Management System</title>
					</head>";
		
				echo "<body><div class='upper'><h1 class='libraryhead'>Library Management System</h1></div>";
				echo "<p>The password you enter does not match.</p>";
				echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='login.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
			}
		}else{
			echo"<head>
					<link href='project1.css' type='text/css' rel='stylesheet'/>	
					<title>Library Management System</title>
				</head>";
				
			echo "<body><div class='upper'><h1 class='libraryhead'>Library Management System</h1></div>";
			echo "<p>The username or email you enter does not exist.</p>";
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='login.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}
	}

	
?>