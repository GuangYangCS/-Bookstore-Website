<?php

	session_start();

	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>
			<title>Paying Fines</title>
		</head>";

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	
	$cardnum = $_POST['cardnum'];
	
	echo "<body><div class='upper'><h1 class='libraryhead'>Paying Fines</h1></div>";
	echo "<p>The card number is ".$cardnum.".</p>";
	
	$sql = "SELECT bl.Loan_id
			FROM book_loans bl, fines f
			WHERE bl.Card_no=$cardnum
				AND bl.Date_in<>'0000-00-00'
				AND bl.Loan_id=f.Loan_id
				AND f.Paid=1";
	$result = mysqli_query($conn, $sql);
	
	if (mysqli_num_rows($result)>0) {
		while($row = mysqli_fetch_assoc($result)){
			$loanid=$row["Loan_id"];
			$sql1="UPDATE fines
				   SET Paid=0
				   WHERE Loan_id=$loanid";
			mysqli_query($conn, $sql1);
		}
	}
	
	echo "<p>Pay successfully.</p>";
	
	$cardNumber = $_SESSION['cardNumber'];
	$userTypeCheck = "SELECT Usertype FROM borrower b WHERE b.Card_no='$cardNumber'";
	$userTypeCheckResult = mysqli_query($conn, $userTypeCheck);
	if(mysqli_num_rows($userTypeCheckResult)>0){
		$row = mysqli_fetch_assoc($userTypeCheckResult);
		if($row["Usertype"] == 'user'){
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='userInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}else{
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}			
	}
	
	mysqli_close($conn);
	
?>