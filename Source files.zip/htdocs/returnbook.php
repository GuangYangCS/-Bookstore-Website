<?php

	session_start();

	echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>
			<title>Return Book</title>
		</head>";
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	
	$userCardNum = $_SESSION['cardNumber'];
	
	$bookid = $_POST['bookid'];
	$trimbookid=trim($bookid);
	$cardnum = $_POST['cardno'];
	$trimcardnum=trim($cardnum);
	$name = $_POST['name'];
	$trimname=trim($name);
	
	echo "<body><div class='upper'><h1 class='libraryhead'>Search Result</h1></div>";
	echo "<table border='1'><tr><th>Book_ID</th><th>Branch_ID</th><th>Card_NO</th><th>Date_Out</th><th>Due_Date</th><th>Date_In</th><th>Loan_ID</th><th>CheckOut</th></tr>";
	
	if(strlen($trimbookid)==10){
		$sql = "SELECT *
				FROM book_loans b
				WHERE b.Book_id='$trimbookid'";
	}else if(strlen($trimbookid)<10 && strlen($trimbookid)>0){
		$sql = "SELECT *
				FROM book_loans b
				WHERE b.Book_id like '%$trimbookid%'";
	}else if(strlen($trimcardnum)!=0 && strlen($trimname)!=0){
		$sql = "SELECT *
				FROM book_loans b
				WHERE b.Card_no like '%$trimcardnum%'
				  AND b.Card_no IN( SELECT borrower.Card_no
								    FROM borrower
		                            WHERE borrower.Fname like '%$trimname%'
		                               OR borrower.Lname like '%$trimname%')";
	}else if(strlen($trimcardnum)!=0){
		$sql = "SELECT *
				FROM book_loans b
				WHERE b.Card_no = $trimcardnum";
	}else if(strlen($trimname)!=0){
		$sql = "SELECT *
				FROM book_loans b
				WHERE b.Card_no IN( SELECT borrower.Card_no
								    FROM borrower
		                            WHERE borrower.Fname like '%$trimname%'
		                               OR borrower.Lname like '%$trimname%')";
	}else{
		$sql = "SELECT *
				FROM book_loans b
				WHERE b.Card_no= $userCardNum";
	}
	
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result)>0) {
		while($row = mysqli_fetch_assoc($result)){
			$chosedloanid = $row["Loan_id"];
			if($row["Date_in"] == '0000-00-00'){
				echo "<tr><td>".$row["Book_id"]."</td><td>".$row["Branch_id"]."</td><td>".$row["Card_no"]."</td><td>".$row["Date_out"]."</td><td>".$row["Due_date"]."</td><td>".$row["Date_in"]."</td><td>".$row["Loan_id"]."</td><td style='text-align: center'>"."<form style='display:inline' action='checkin.php' method='post'><input type='hidden' name='loanid' value='$chosedloanid'><input type='submit' value='Check In'></form>"."</td></tr>";
			}else{
				echo "<tr><td>".$row["Book_id"]."</td><td>".$row["Branch_id"]."</td><td>".$row["Card_no"]."</td><td>".$row["Date_out"]."</td><td>".$row["Due_date"]."</td><td>".$row["Date_in"]."</td><td>".$row["Loan_id"]."</td><td style='text-align: center'>"."<button onclick=indication()>Check In</button>"."</td></tr><script>function indication(){alert('This book had been checked in before.');}</script>";
			}
		}
	}else{
		echo "<p>0 results</p>";
	}
	echo "</table>";
	
	$cardNumber = $_SESSION['cardNumber'];
	$userTypeCheck = "SELECT Usertype FROM borrower b WHERE b.Card_no='$cardNumber'";
	$userTypeCheckResult = mysqli_query($conn, $userTypeCheck);
	if(mysqli_num_rows($userTypeCheckResult)>0){
		$row = mysqli_fetch_assoc($userTypeCheckResult);
		if($row["Usertype"] == 'user'){
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='userInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}else{
			echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='adminInterface.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
		}			
	}
	
	mysqli_close($conn);
	
?>