<?php
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "library";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(mysqli_connect_errno()){
		echo "Failed to connect to MySQL:".mysqli_connect_error()."<br/>";
	}
	
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$emailsignup = $_POST['emailsignup'];
	$usernamesignup = $_POST['usernamesignup'];
	$passwordsignup = $_POST['passwordsignup'];
	
	$trimfname=trim($fname);
	$trimlname=trim($lname);
	$trimemailsignup=trim($emailsignup);
	$trimusernamesignup=trim($usernamesignup);
	$trimpasswordsignup=trim($passwordsignup);
	
	if(strlen($trimfname)==0 || strlen($trimlname)==0 || strlen($trimemailsignup)==0 || strlen($trimusernamesignup)==0 || strlen($trimpasswordsignup)==0){
		echo"<head>
			<link href='project1.css' type='text/css' rel='stylesheet'/>	
			<title>Library Management System</title>
		</head>";
		echo "<body><div class='upper'><h1 class='libraryhead'>Library Management System</h1></div>";
		echo "<p>You must enter the last name, first name, email address, username and password.</p>";
		
	}else{
		$duplicate_check1 = "SELECT * FROM borrower b WHERE b.Username='$trimusernamesignup'";
		$duplicate_check2 = "SELECT * FROM borrower b WHERE b.Email_Address='$trimemailsignup'";
		$check_result1 = mysqli_query($conn, $duplicate_check1);
		$check_result2 = mysqli_query($conn, $duplicate_check2);
		if(mysqli_num_rows($check_result1)>0){
			include ("login.html");
			echo "<p>The username you enter already exists.</p>";
		}else if(mysqli_num_rows($check_result2)>0){
			include ("login.html");
			echo "<p>The email you enter already exists.</p>";
		}else{
			$sql = "INSERT INTO borrower(Card_no, Fname, Lname, Email_Address, Username, Password)
					VALUES(NULL, '$trimfname', '$trimlname', '$trimemailsignup', '$trimusernamesignup', '$trimpasswordsignup')";
			$result = mysqli_query($conn, $sql);
			$sql1 = "SELECT Card_no
					 FROM borrower
					 WHERE Fname='$trimfname' AND Lname='$trimlname' AND Email_Address='$trimemailsignup'";
			$result1 = mysqli_query($conn, $sql1);
			echo"<head>
				<link href='project1.css' type='text/css' rel='stylesheet'/>	
				<title>Library Management System</title>
			</head>";
			echo "<body><div class='upper'><h1 class='libraryhead'>Library Management System</h1></div>";
			if(mysqli_num_rows($result1)>0){
				$row = mysqli_fetch_assoc($result1);
				$cardnumber = $row["Card_no"];
			}
			echo "<p>A new account is created successfully, and the card number is ".$cardnumber.".</p>";
		}
	}

	mysqli_close($conn);
	
	echo "<div style='padding-left: 20px; padding-top: 20px;'><a href='login.html'><button class='btn' style='font-size: 20px;'>Return</button></a></div></body>";
	
?>