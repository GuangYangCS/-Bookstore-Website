$(document).ready(function() {
		
	$("#username").after("<span id='s1'> The username field must contain only alphabetical or numeric characters. The email address field should contain a @ character.</span>");
	
	$("#password").after("<span id='s2'> The password field should be exactly 8 characters long.</span>");
	
	$("#fname").after("<span id='s3'> The first name field must contain only alphabetical characters.</span>");
	
	$("#lname").after("<span id='s4'> The last name field must contain only alphabetical characters.</span>");
	
	$("#usernamesignup").after("<span id='s5'> The username field must contain only alphabetical or numeric characters.</span>");
	
	$("#emailsignup").after("<span id='s6'> The email address field should contain a @ character.</span>");
	
	$("#passwordsignup").after("<span id='s7'> The password field should be exactly 8 characters long.</span>");
	
	$("span").hide();
	
	$("#username").focus(function(){
		$("#s1").removeClass().text("The username field must contain only alphabetical or numeric characters. The email address field should contain a @ character.").show().addClass("info");
	});
	$("#username").blur(function(){
		if($(this).val().length === 0){
			$("#s1").hide();
		}else{
			if(emailValidation($("#username")) || usernameValidation($("#username"))){
				$("#s1").removeClass().addClass("ok").text("OK");
			}else{
				$("#s1").removeClass().addClass("error").text("ERROR");
			}
		}
	});
	
	
	$("#password").focus(function(){
		$("#s2").removeClass().text("The password field should be exactly 8 characters long.").show().addClass("info");
	});
	$("#password").blur(function(){
		if($(this).val().length === 0){
			$("#s2").hide();
		}else{
			if(passwordValidation($("#password"), 8)){
				$("#s2").removeClass().addClass("ok").text("OK");
			}else{
				$("#s2").removeClass().addClass("error").text("ERROR");
			}
		}	
	});
	
	
	$("#fname").focus(function(){
		$("#s3").removeClass().text("The first name field must contain only alphabetical characters.").show().addClass("info");
	});
	$("#fname").blur(function(){
		if($(this).val().length === 0){
			$("#s3").hide();
		}else{
			if(usernameValidation($("#fname"))){
				$("#s3").removeClass().addClass("ok");
			}else{
				$("#s3").removeClass().addClass("error").text("ERROR");
			}
		}
	});
	
	$("#lname").focus(function(){
		$("#s4").removeClass().text("The last name field must contain only alphabetical characters.").show().addClass("info");
	});
	$("#lname").blur(function(){
		if($(this).val().length === 0){
			$("#s4").hide();
		}else{
			if(usernameValidation($("#lname"))){
				$("#s4").removeClass().addClass("ok");
			}else{
				$("#s4").removeClass().addClass("error").text("ERROR");
			}
		}
	});
	
	
	$("#usernamesignup").focus(function(){
		$("#s5").removeClass().text("The username field must contain only alphabetical or numeric characters.").show().addClass("info");
	});
	$("#usernamesignup").blur(function(){
		if($(this).val().length === 0){
			$("#s5").hide();
		}else{
			if(usernameValidation($("#usernamesignup"))){
				$("#s5").removeClass().addClass("ok");
			}else{
				$("#s5").removeClass().addClass("error").text("ERROR");
			}
		}
	});
	
	
	$("#emailsignup").focus(function(){
		$("#s6").removeClass().text("The email address field should contain a @ character.").show().addClass("info");
	});
	$("#emailsignup").blur(function(){
		if($(this).val().length === 0){
			$("#s6").hide();
		}else{
			if(emailValidation($("#emailsignup"))){
				$("#s6").removeClass().addClass("ok");
			}else{
				$("#s6").removeClass().addClass("error").text("ERROR");
			}
		}
	});
	
	
	$("#passwordsignup").focus(function(){
		$("#s7").removeClass().text("The password field should be exactly 8 characters long.").show().addClass("info");
	});
	$("#passwordsignup").blur(function(){
		if($(this).val().length === 0){
			$("#s7").hide();
		}else{
			if(passwordValidation($("#passwordsignup"), 8)){
				$("#s7").removeClass().addClass("ok");
			}else{
				$("#s7").removeClass().addClass("error").text("ERROR");
			}
		}	
	});
	
});

	function usernameValidation(inputtext){
		var alphaExp = /^[0-9a-zA-Z]+$/;
	 	if(inputtext.val().match(alphaExp)){
			return true;
		}else{
			return false;
		}
    }
    
    function passwordValidation(inputtext, min){
   		var uInput = inputtext.val();
		if(uInput.length == min){
			return true;
		}else{
			return false;
		}
	}
	
	function emailValidation(inputtext){
		var emailExp = /@/;
		if(inputtext.val().match(emailExp)){
			return true;
		}else{
			return false;
		}
	}
	
			function isTrue() {
				var x = document.forms["registerForm"]["fname"].value;
				var y = document.forms["registerForm"]["lname"].value;
				var z = document.forms["registerForm"]["usernamesignup"].value;
				var u = document.forms["registerForm"]["emailsignup"].value;
				var w = document.forms["registerForm"]["passwordsignup"].value;
				
				var alphaExp = /^[0-9a-zA-Z]+$/;
				var emailExp = /@/;
				var b1 = true;
				var b2 = true;
				var b3 = true;
				var b4 = true;
				var b5 = true;
								
				if (!x.match(alphaExp)) {
					alert("First name must be filled out following the indicative rule.");
					b1 = false;
				}
				if (!y.match(alphaExp)) {
					alert("Last name must be filled out following the indicative rule.");
					b2 = false;
				}
				if (!z.match(alphaExp)) {
					alert("Username must be filled out following the indicative rule.");
					b3 = false;
				}else{
					showUsernameHint(z);
				}
				if(!u.match(emailExp)){
					alert("Email must be filled out following the indicative rule.");
					b4 = false;
				}else{
					showEmailHint(u);
				}
				if(w.length != 8){
					alert("Password must be filled out following the indicative rule.");
					b5 = false;
				}
				
				return (b1&&b2&&b3&&b4&&b5);
			}
			
	function loginCheck() {
		var i = document.forms["loginForm"]["username"].value;
		var j = document.forms["loginForm"]["password"].value;
		
		var alphaExp = /^[0-9a-zA-Z]+$/;
		var b1 = true;
		var b2 = true;
		if (!i.match(alphaExp)) {
			alert("Username must be filled out following the indicative rule.");
			b1 = false;
		}else{
			showUsernameHint(i);
		}
		if(j.length != 8){
			alert("Password must be filled out following the indicative rule.");
			b2 = false;
		}
		return (b1&&b2);
	}
	
	function showUsernameHint(str) {
		$("#usernamesignup").after("<span id='usernameTxtHint'></span>");
		if (str.length == 0) { 
			document.getElementById("usernameTxtHint").innerHTML = "";
			return;
		} else {
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
					document.getElementById("usernameTxtHint").innerHTML = xmlhttp.responseText;
				}
			};
			xmlhttp.open("GET", "getUsernameHint.php?q=" + str, true);
			xmlhttp.send();
		}
	}
	
	function showEmailHint(str) {
		$("#emailsignup").after("<span id='emailTxtHint'></span>");
		if (str.length == 0) { 
			document.getElementById("emailTxtHint").innerHTML = "";
			return;
		} else {
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
					document.getElementById("emailTxtHint").innerHTML = xmlhttp.responseText;
				}
			};
			xmlhttp.open("GET", "getEmailHint.php?q=" + str, true);
			xmlhttp.send();
		}
	}
	
